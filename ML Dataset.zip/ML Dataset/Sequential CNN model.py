# -*- coding: utf-8 -*-
"""
Created on Tue Mar 26 10:12:26 2024

@author: annie
"""

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.preprocessing import image
from tensorflow.keras import layers
from tensorflow import keras
import tensorflow as tf
import os

#ignore information messages from tensorflow
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

# Define batch size and image dimensions
img_height = 170  #average image height of dataset images
img_width = 170  #average image width of dataset images
batch_size = 32

# Defines variable for directory containing all images
train_dir = 'Train'
test_dir = 'Test'


# Create a dataset from directory
ds_train = tf.keras.preprocessing.image_dataset_from_directory(
    train_dir, 
    labels = 'inferred',
    label_mode = "int", #categorical, binary
    #class_names=['0', '1', '2']
    color_mode = 'grayscale',
    batch_size = batch_size,
    image_size = (img_height, img_width), #reshape if not correct size
    shuffle = True, 
    seed = 123,
    validation_split = 0.15, 
    subset = "training",
    )

ds_validation = tf.keras.preprocessing.image_dataset_from_directory(
    train_dir,
    labels = 'inferred',
    label_mode = "int", #categorical, binary
    #class_names=['0', '1', '2']
    color_mode = 'grayscale',
    batch_size = batch_size,
    image_size = (img_height, img_width), #reshape if not correct size
    shuffle = True, 
    seed = 123,
    validation_split = 0.15, 
    subset = "validation",
    )

ds_test = tf.keras.preprocessing.image_dataset_from_directory(
    test_dir,
    labels = 'inferred',
    label_mode = "int", #categorical, binary
    #class_names=['0', '1', '2']
    color_mode = 'grayscale',
    batch_size = batch_size,
    image_size = (img_height, img_width), #reshape if not correct size
    shuffle = True, 
    seed = 123,
    )


# Build model
model = keras.Sequential(
    [
    keras.Input(shape=(img_height, img_width, 1)),
    layers.Conv2D(32, 1, padding='same', activation='relu'),
    layers.MaxPooling2D(pool_size=(2, 2), padding='same'),
    layers.Conv2D(64, 1, padding='same', activation='relu'),
    layers.MaxPooling2D(pool_size=(2, 2), padding='same'),
    layers.Conv2D(128, 1, padding='same', activation='relu'),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10)
    ])


print(model.summary())

model.compile(
    loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
    optimizer = keras.optimizers.Adam(learning_rate=3e-4),
    metrics = ['accuracy'],
    )


model.fit(
    ds_train, 
    batch_size=batch_size, 
    epochs = 50, 
    verbose = 2, 
    validation_data = ds_validation
    )


model.evaluate(
    ds_test, 
    batch_size=batch_size, 
    verbose = 2
    )